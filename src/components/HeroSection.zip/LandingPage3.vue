<script setup lang="ts">
import { ref, computed } from 'vue'

/* ── Simulador state ── */
const valorEmprestimo = ref(69000)
const parcelasSelecionada = ref(18)
const opcoesParcelas = [6, 12, 16, 18, 24, 36]

const valorFormatado = computed(() =>
  valorEmprestimo.value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
  })
)

const parcelaMin = computed(() => {
  const v = valorEmprestimo.value / parcelasSelecionada.value
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })
})

const parcelaMax = computed(() => {
  const v = (valorEmprestimo.value / parcelasSelecionada.value) * 1.75
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })
})

function incrementar() {
  valorEmprestimo.value = Math.min(200000, valorEmprestimo.value + 1000)
}

function decrementar() {
  valorEmprestimo.value = Math.max(1000, valorEmprestimo.value - 1000)
}
</script>

<template>
  <div class="w-full max-w-[414px] mx-auto bg-white font-roboto text-white text-center text-[18px] relative overflow-hidden">

    <!-- ══════════════════════════════════════ -->
    <!-- HEADER — h-header (63px)              -->
    <!-- ══════════════════════════════════════ -->
    <header class="flex items-center justify-between px-5 h-header bg-white">
      <img src="/dock.png" alt="Dock" class="h-8 w-auto" />
      <button class="flex h-10 w-10 flex-col items-center justify-center gap-[3px] rounded-lg bg-[#ececec]" aria-label="Menu">
        <span class="block h-[2px] w-4 rounded-full bg-[#9a9a9a]"></span>
        <span class="block h-[2px] w-4 rounded-full bg-[#9a9a9a]"></span>
        <span class="block h-[2px] w-4 rounded-full bg-[#9a9a9a]"></span>
      </button>
    </header>

    <!-- ══════════════════════════════════════ -->
    <!-- HERO — bloco #1cc0c0, radius 34px     -->
    <!-- ══════════════════════════════════════ -->
    <section class="relative">
      <div class="relative z-10 mx-[11px] mt-[20px]">
        <div class="inline-flex flex-col items-start justify-start rounded-hero-block bg-dock-tertiary w-[259px] h-[154px] px-[25px] pt-[22px] text-left">
          <!-- "FEITO DE PESSOAS, PARA PESSOAS." — 18px, weight 500, uppercase, 2 linhas -->
          <p class="text-[18px] font-medium text-white uppercase leading-tight w-[170px]">
            Feito de pessoas,<br/>para pessoas.
          </p>
          <!-- "EMPRÉSTIMO ONLINE, RÁPIDO E SEGURO." — 22px, bold, uppercase, tracking -0.06em, lh 24px -->
          <p class="text-[22px] font-bold text-white uppercase leading-[24px] tracking-[-0.06em] mt-[16px] w-[224px]">
            Empréstimo Online,<br/>Rápido e Seguro.
          </p>
        </div>
      </div>

      <!-- Imagem hero — overlap -210px conforme DESIGN_SYSTEM §4.2 -->
      <div class="relative mx-auto flex w-full justify-center">
        <img
          src="/image-header.png"
          alt="Pessoa usando tablet"
          class="-mt-[210px] w-full max-w-[416px] object-contain relative z-0"
        />
      </div>
    </section>

    <!-- ══════════════════════════════════════ -->
    <!-- SIMULADOR — fundo #1cc0c0, sem gap    -->
    <!-- ══════════════════════════════════════ -->
    <section class="bg-dock-tertiary px-[20px] pt-[40px] pb-[40px]">
      <!-- "De quanto você precisa?" — 26px, bold -->
      <h2 class="text-[26px] font-bold text-white mb-[20px]">
        De quanto você precisa?
      </h2>

      <!-- Campo valor — w-valor-campo (229px), h-valor-campo (81px), bg #eeff88, border 1px #fff -->
      <div class="mx-auto w-valor-campo h-valor-campo bg-dock-yellow border border-white flex items-center justify-center mb-[20px]">
        <span class="text-[30px] font-medium text-dock-primary">{{ valorFormatado }}</span>
      </div>

      <!-- Slider com +/- e <input type="range"> FUNCIONAL -->
      <div class="flex items-center gap-[10px] mx-auto max-w-[375px] mb-[30px] px-[19px]">
        <!-- Botão + — w-slider-ctrl (29px), h-slider-ctrl (29px) -->
        <button
          class="w-slider-ctrl h-slider-ctrl bg-dock-primary flex items-center justify-center text-[24px] font-medium text-white flex-shrink-0 cursor-pointer"
          @click="incrementar"
        >+</button>

        <!-- Slider FUNCIONAL — <input type="range"> nativo estilizado -->
        <div class="flex-1 relative">
          <input
            type="range"
            :min="1000"
            :max="200000"
            :step="1000"
            v-model.number="valorEmprestimo"
            class="w-full h-[10px] appearance-none cursor-pointer bg-dock-slider-inactive rounded-none
                   [&::-webkit-slider-runnable-track]:h-[10px]
                   [&::-webkit-slider-runnable-track]:rounded-none
                   [&::-webkit-slider-thumb]:appearance-none
                   [&::-webkit-slider-thumb]:w-[24px]
                   [&::-webkit-slider-thumb]:h-[24px]
                   [&::-webkit-slider-thumb]:bg-dock-yellow
                   [&::-webkit-slider-thumb]:cursor-pointer
                   [&::-webkit-slider-thumb]:-mt-[7px]
                   [&::-moz-range-thumb]:w-[24px]
                   [&::-moz-range-thumb]:h-[24px]
                   [&::-moz-range-thumb]:bg-dock-yellow
                   [&::-moz-range-thumb]:border-none
                   [&::-moz-range-thumb]:rounded-none
                   [&::-moz-range-thumb]:cursor-pointer
                   [&::-moz-range-track]:h-[10px]
                   [&::-moz-range-track]:bg-dock-slider-inactive"
          />
        </div>

        <!-- Botão - — w-slider-ctrl (29px), h-slider-ctrl (29px) -->
        <button
          class="w-slider-ctrl h-slider-ctrl bg-dock-primary flex items-center justify-center text-[24px] font-medium text-white flex-shrink-0 cursor-pointer"
          @click="decrementar"
        >-</button>
      </div>

      <!-- "Em quantas vezes?" — 26px, bold -->
      <h3 class="text-[26px] font-bold text-white mb-[24px]">
        Em quantas vezes?
      </h3>

      <!-- Grid parcelas 3x2 — w-parcela (83px), h-parcela (65px), border 1px #fff -->
      <div class="grid grid-cols-3 gap-0 mx-auto w-[249px] mb-[24px]">
        <button
          v-for="parcela in opcoesParcelas"
          :key="parcela"
          class="w-parcela h-parcela border border-white flex items-center justify-center text-[30px] font-medium cursor-pointer"
          :class="parcela === parcelasSelecionada
            ? 'bg-dock-yellow text-dock-primary'
            : 'bg-dock-primary text-white'"
          @click="parcelasSelecionada = parcela"
        >
          {{ parcela }}
        </button>
      </div>

      <!-- Parcelas mensal — 26px, light label / medium value -->
      <div class="mb-[16px]">
        <span class="text-[26px] font-light text-white">Parcelas mensal*</span>
        <br/>
        <span class="text-[26px] font-medium text-white">{{ parcelaMin }} a {{ parcelaMax }}</span>
      </div>

      <!-- Taxa de juros — 24px -->
      <div class="mb-[24px]">
        <span class="text-[24px] font-light text-white">Taxa de Juros*</span>
        <br/>
        <span class="text-[24px] font-medium text-white">1,99% a 4,99%</span>
      </div>

      <!-- Botão "SOLICITE AGORA" — w-btn (317px), h-btn (60px), rounded-btn (3px) -->
      <button class="w-btn h-btn rounded-btn bg-dock-primary mx-auto block cursor-pointer">
        <span class="font-red-hat text-[18px] font-semibold text-white uppercase">SOLICITE AGORA</span>
      </button>

      <!-- Disclaimer — 16px, regular -->
      <p class="text-[16px] font-normal text-white mt-[24px] mx-auto max-w-[372px]">
        * As taxas e valores acima são apenas<br/>
        ilustrativos. As taxas reais serão calculadas de<br/>
        acordo com seu perfil de crédito quando você<br/>
        solicitar uma proposta personalizada.
      </p>
    </section>

    <!-- ══════════════════════════════════════ -->
    <!-- COMO FUNCIONA — fundo branco          -->
    <!-- ══════════════════════════════════════ -->
    <section class="bg-white py-[47px] px-[20px]">
      <!-- "Como funciona?" — 26px, bold, #00d8d8 -->
      <h2 class="text-[26px] font-bold text-dock-primary mb-[40px]">
        Como funciona?
      </h2>

      <div class="max-w-[300px] mx-auto space-y-[20px] mb-[40px]">
        <!-- Passo 1 -->
        <div class="flex items-start gap-[16px]">
          <div class="w-circle h-circle rounded-full bg-dock-primary flex items-center justify-center flex-shrink-0">
            <span class="text-[24px] text-white leading-none">1</span>
          </div>
          <div class="text-left">
            <h3 class="text-[19px] font-bold text-dock-primary">Preencha a proposta</h3>
            <p class="text-[16px] font-light text-dock-text-gray tracking-[0.03em] mt-[4px] leading-snug">
              Contrate seu empréstimo 100%<br/>online. Fácil, rápido e seguro.
            </p>
          </div>
        </div>

        <!-- Passo 2 -->
        <div class="flex items-start gap-[16px]">
          <div class="w-circle h-circle rounded-full bg-dock-primary flex items-center justify-center flex-shrink-0">
            <span class="text-[24px] text-white leading-none">2</span>
          </div>
          <div class="text-left">
            <h3 class="text-[19px] font-bold text-dock-primary">Aguarde a aprovação</h3>
            <p class="text-[16px] font-light text-dock-text-gray tracking-[0.04em] mt-[4px] leading-snug">
              Após a análise rápida feita<br/>pelos consultores.
            </p>
          </div>
        </div>

        <!-- Passo 3 -->
        <div class="flex items-start gap-[16px]">
          <div class="w-circle h-circle rounded-full bg-dock-primary flex items-center justify-center flex-shrink-0">
            <span class="text-[24px] text-white leading-none">3</span>
          </div>
          <div class="text-left">
            <h3 class="text-[19px] font-bold text-dock-primary">Receba o seu dinheiro!</h3>
            <p class="text-[16px] font-light text-dock-text-gray tracking-[0.04em] mt-[4px] leading-snug">
              Leia os termos, assine o contrato<br/>e receba o seu dinheiro.
            </p>
          </div>
        </div>
      </div>

      <!-- Botão "CONTRATE" — w-btn, h-btn, rounded-btn -->
      <button class="w-btn h-btn rounded-btn bg-dock-primary mx-auto block cursor-pointer">
        <span class="font-red-hat text-[18px] font-semibold text-white uppercase">CONTRATE</span>
      </button>
    </section>

    <!-- ══════════════════════════════════════ -->
    <!-- BENEFÍCIOS — fundo #e6e6e6            -->
    <!-- ══════════════════════════════════════ -->
    <section class="bg-dock-bg-light py-[49px] px-[20px]">
      <!-- "Atendendo suas necessidades" — 26px, bold, #00d8d8, 2 linhas -->
      <h2 class="text-[26px] font-bold text-dock-primary mb-[26px]">
        Atendendo suas<br/>necessidades
      </h2>

      <!-- Grid 2x2 — w-card (147px), h-card (234px) -->
      <div class="grid grid-cols-2 gap-[10px] mx-auto w-[307px]">
        <!-- Card 1: Fácil e rápido — ícone monitor/check -->
        <div class="w-card h-card bg-white flex flex-col items-center justify-center text-center px-[8px]">
          <div class="w-[78px] h-[70px] mb-[20px] flex items-center justify-center">
            <svg width="78" height="70" viewBox="0 0 78 70" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="5" y="2" width="68" height="46" rx="2" stroke="#00d8d8" stroke-width="1.8" fill="none"/>
              <line x1="25" y1="48" x2="53" y2="48" stroke="#00d8d8" stroke-width="1.8"/>
              <line x1="39" y1="48" x2="39" y2="58" stroke="#00d8d8" stroke-width="1.8"/>
              <line x1="28" y1="58" x2="50" y2="58" stroke="#00d8d8" stroke-width="1.8"/>
              <polyline points="24,24 33,33 54,16" stroke="#00d8d8" stroke-width="2.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <h3 class="text-[17px] font-bold text-dock-primary leading-tight">Fácil e<br/>rápido</h3>
          <p class="text-[14px] font-light text-dock-text-dark mt-[4px] leading-tight">Online e<br/>confortável<br/>para você!</p>
        </div>

        <!-- Card 2: Tempo para pagar — ícone calendário -->
        <div class="w-card h-card bg-white flex flex-col items-center justify-center text-center px-[8px]">
          <div class="w-[61px] h-[70px] mb-[20px] flex items-center justify-center">
            <svg width="61" height="70" viewBox="0 0 61 70" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="3" y="10" width="55" height="52" rx="2" stroke="#00d8d8" stroke-width="1.8" fill="none"/>
              <line x1="3" y1="24" x2="58" y2="24" stroke="#00d8d8" stroke-width="1.8"/>
              <line x1="18" y1="4" x2="18" y2="14" stroke="#00d8d8" stroke-width="1.8" stroke-linecap="round"/>
              <line x1="43" y1="4" x2="43" y2="14" stroke="#00d8d8" stroke-width="1.8" stroke-linecap="round"/>
              <rect x="10" y="32" width="10" height="8" rx="1" fill="#00d8d8"/>
              <rect x="26" y="32" width="10" height="8" rx="1" stroke="#00d8d8" stroke-width="1" fill="none"/>
              <rect x="42" y="32" width="10" height="8" rx="1" stroke="#00d8d8" stroke-width="1" fill="none"/>
            </svg>
          </div>
          <h3 class="text-[17px] font-bold text-dock-primary leading-tight">Tempo para<br/>pagar</h3>
          <p class="text-[14px] font-light text-dock-text-dark mt-[4px] leading-tight">Parcele em<br/>até 36 vezes.</p>
        </div>

        <!-- Card 3: Menor taxa do mercado — ícone moedas -->
        <div class="w-card h-card bg-white flex flex-col items-center justify-center text-center px-[8px]">
          <div class="w-[70px] h-[67px] mb-[20px] flex items-center justify-center">
            <svg width="70" height="67" viewBox="0 0 70 67" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="24" cy="38" r="18" stroke="#00d8d8" stroke-width="1.8" fill="none"/>
              <circle cx="46" cy="38" r="18" stroke="#00d8d8" stroke-width="1.8" fill="none"/>
              <line x1="24" y1="30" x2="24" y2="46" stroke="#00d8d8" stroke-width="1.8"/>
              <line x1="16" y1="38" x2="32" y2="38" stroke="#00d8d8" stroke-width="1.8"/>
            </svg>
          </div>
          <h3 class="text-[17px] font-bold text-dock-primary leading-tight">Menor taxa<br/>do mercado</h3>
          <p class="text-[14px] font-light text-dock-text-dark mt-[4px] leading-tight">Taxas a partir<br/>de 1.99% a.m.</p>
        </div>

        <!-- Card 4: R$ — ícone carteira/nota -->
        <div class="w-card h-card bg-white flex flex-col items-center justify-center text-center px-[8px]">
          <div class="w-[60px] h-[70px] mb-[20px] flex items-center justify-center">
            <svg width="60" height="70" viewBox="0 0 60 70" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="3" y="16" width="54" height="38" rx="2" stroke="#00d8d8" stroke-width="1.8" fill="none"/>
              <circle cx="30" cy="35" r="9" stroke="#00d8d8" stroke-width="1.8" fill="none"/>
              <line x1="12" y1="16" x2="12" y2="54" stroke="#00d8d8" stroke-width="1.2"/>
              <line x1="48" y1="16" x2="48" y2="54" stroke="#00d8d8" stroke-width="1.2"/>
            </svg>
          </div>
          <h3 class="text-[17px] font-bold text-dock-primary leading-tight">R$</h3>
          <p class="text-[14px] font-light text-dock-text-dark mt-[4px] leading-tight">Parcela que<br/>cabe no seu<br/>bolso.</p>
        </div>
      </div>
    </section>

    <!-- ══════════════════════════════════════ -->
    <!-- FOOTER — barra preta + corpo branco   -->
    <!-- ══════════════════════════════════════ -->
    <footer>
      <!-- Barra preta — h-footer-bar (84px) -->
      <div class="bg-dock-black w-full h-footer-bar flex flex-col items-center justify-center px-[20px]">
        <p class="text-[12px] font-normal text-white font-roboto">Plataforma operada por Dock</p>
        <p class="text-[12px] font-normal text-white font-roboto mt-[8px]">política de privacidade e cookies</p>
      </div>

      <!-- Corpo footer — Red Hat Display, #777 -->
      <div class="bg-white px-[61px] pt-[28px] pb-[20px] text-center">
        <p class="text-[12px] text-dock-text-muted font-red-hat">
          <b>Dock - Instituição de pagamentos regulada pelo Bacen</b>
        </p>
        <p class="text-[12px] text-dock-text-muted font-red-hat mt-[12px] leading-relaxed">
          A Dock fornece tecnologia para pagamentos e banking na América Latina. Pioneira e precursora, é o motor por
          trás da aceleração dos serviços financeiros digitais na região, reunindo soluções de emissão de cartões, conta
          digital, adquirência e prevenção a fraude, acelerando a capacidade das empresas de oferecer serviços
          inovadores aos seus clientes. Conheça mais sobre a Dock, nossas certificações e compromisso
          fundamentados nos pilares de ESG para transformarmos o futuro.
        </p>
        <p class="text-[12px] text-dock-text-muted font-red-hat mt-[20px] leading-relaxed">
          © Copyright 2026 - DOCK INSTITUICAO DE PAGAMENTO S.A. - CNPJ 13.370.835/0001-85<br/>
          Av. Tambore, 267, Alphaville, Barueri - SP<br/>
          06460-000.
        </p>
      </div>
    </footer>
  </div>
</template>
