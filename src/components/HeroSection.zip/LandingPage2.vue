<script setup lang="ts">
import { ref, computed } from 'vue'

/* ── Simulador ── */
const valorEmprestimo = ref(69000)
const parcelasSelecionada = ref(18)
const opcoesParcelas = [6, 12, 16, 18, 24, 36]

const valorFormatado = computed(() =>
  valorEmprestimo.value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
  })
)

const parcelaMin = computed(() => {
  const v = valorEmprestimo.value / parcelasSelecionada.value
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })
})

const parcelaMax = computed(() => {
  const v = (valorEmprestimo.value / parcelasSelecionada.value) * 1.75
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })
})

const sliderPercent = computed(() => {
  return ((valorEmprestimo.value - 1000) / (200000 - 1000)) * 100
})
</script>

<template>
  <div class="w-full max-w-[414px] mx-auto bg-white font-roboto text-white text-center text-[18px] relative overflow-hidden">

    <!-- ═══════════════════════════════════════════ -->
    <!-- HEADER — 63px, logo esquerda, menu direita -->
    <!-- ═══════════════════════════════════════════ -->
    <header class="flex items-center justify-between px-5 h-[63px] bg-white">
      <img src="/dock.png" alt="Dock" class="h-8 w-auto" />
      <button class="flex h-10 w-10 flex-col items-center justify-center gap-[3px] rounded-lg bg-[#ececec]" aria-label="Menu">
        <span class="block h-[2px] w-4 rounded-full bg-[#9a9a9a]"></span>
        <span class="block h-[2px] w-4 rounded-full bg-[#9a9a9a]"></span>
        <span class="block h-[2px] w-4 rounded-full bg-[#9a9a9a]"></span>
      </button>
    </header>

    <!-- ═══════════════════════════════════════════ -->
    <!-- HERO — bloco #1cc0c0 border-radius:34px    -->
    <!-- ═══════════════════════════════════════════ -->
    <section class="relative">
      <div class="relative z-10 mx-[11px] mt-[20px]">
        <!-- Bloco teal 259x154, border-radius 34px -->
        <div class="inline-flex flex-col items-start justify-start rounded-[34px] bg-[#1cc0c0] w-[259px] h-[154px] px-[25px] pt-[22px] text-left">
          <!-- "FEITO DE PESSOAS, PARA PESSOAS." — 18px, weight 500, uppercase, 2 linhas -->
          <p class="text-[18px] font-medium text-white uppercase leading-tight w-[170px]">
            Feito de pessoas,<br/>para pessoas.
          </p>
          <!-- "EMPRÉSTIMO ONLINE, RÁPIDO E SEGURO." — 22px, bold, uppercase, letter-spacing -0.06em, line-height 24px -->
          <p class="text-[22px] font-bold text-white uppercase leading-[24px] tracking-[-0.06em] mt-[16px] w-[224px]">
            Empréstimo Online,<br/>Rápido e Seguro.
          </p>
        </div>
      </div>

      <!-- Imagem hero sobreposta -->
      <div class="relative mx-auto flex w-full justify-center">
        <img
          src="/image-header.png"
          alt="Pessoa usando tablet"
          class="-mt-[210px] w-full max-w-[416px] object-contain relative z-0"
        />
      </div>
    </section>

    <!-- ═══════════════════════════════════════════ -->
    <!-- SIMULADOR — fundo #1cc0c0                  -->
    <!-- ═══════════════════════════════════════════ -->
    <section class="bg-[#1cc0c0] px-[20px] pt-[40px] pb-[40px]">
      <!-- "De quanto você precisa?" — 26px, bold, branco -->
      <h2 class="text-[26px] font-bold text-white mb-[20px]">
        De quanto você precisa?
      </h2>

      <!-- Campo de valor — 229x81, bg #eeff88, border 1px #fff -->
      <div class="mx-auto w-[229px] h-[81px] bg-[#eeff88] border border-white flex items-center justify-center mb-[20px]">
        <span class="text-[30px] font-medium text-[#00d8d8]">{{ valorFormatado }}</span>
      </div>

      <!-- Slider com +/- -->
      <div class="flex items-center gap-[10px] mx-auto max-w-[375px] mb-[30px] px-[19px]">
        <!-- Botão + (29x29, bg #00d8d8) -->
        <button
          class="w-[29px] h-[29px] bg-[#00d8d8] flex items-center justify-center text-[24px] font-medium text-white flex-shrink-0"
          @click="valorEmprestimo = Math.min(200000, valorEmprestimo + 1000)"
        >+</button>

        <!-- Slider track -->
        <div class="flex-1 relative h-[10px]">
          <div class="absolute inset-0 bg-[#b9b9b9] h-[10px]"></div>
          <div class="absolute left-0 top-0 bg-white h-[10px]" :style="{ width: sliderPercent + '%' }"></div>
          <!-- Thumb -->
          <div
            class="absolute top-[50%] -translate-y-1/2 w-[24px] h-[24px] bg-white rounded-none flex items-center justify-center"
            :style="{ left: sliderPercent + '%', marginLeft: '-12px' }"
          >
            <div class="w-[14px] h-[13px] bg-[#eeff88]"></div>
          </div>
        </div>

        <!-- Botão - (29x29, bg #00d8d8) -->
        <button
          class="w-[29px] h-[29px] bg-[#00d8d8] flex items-center justify-center text-[24px] font-medium text-white flex-shrink-0"
          @click="valorEmprestimo = Math.max(1000, valorEmprestimo - 1000)"
        >-</button>
      </div>

      <!-- "Em quantas vezes?" — 26px, bold -->
      <h3 class="text-[26px] font-bold text-white mb-[24px]">
        Em quantas vezes?
      </h3>

      <!-- Grid parcelas 3x2 — 83x65 cada, border 1px #fff -->
      <div class="grid grid-cols-3 gap-0 mx-auto w-[249px] mb-[24px]">
        <button
          v-for="parcela in opcoesParcelas"
          :key="parcela"
          class="w-[83px] h-[65px] border border-white flex items-center justify-center text-[30px] font-medium cursor-pointer"
          :class="parcela === parcelasSelecionada
            ? 'bg-[#eeff88] text-[#00d8d8]'
            : 'bg-[#00d8d8] text-white'"
          @click="parcelasSelecionada = parcela"
        >
          {{ parcela }}
        </button>
      </div>

      <!-- Parcelas mensal — 26px -->
      <div class="mb-[16px]">
        <span class="text-[26px] font-light text-white">Parcelas mensal*</span>
        <br/>
        <span class="text-[26px] font-medium text-white">{{ parcelaMin }} a {{ parcelaMax }}</span>
      </div>

      <!-- Taxa de juros — 24px -->
      <div class="mb-[24px]">
        <span class="text-[24px] font-light text-white">Taxa de Juros*</span>
        <br/>
        <span class="text-[24px] font-medium text-white">1,99% a 4,99%</span>
      </div>

      <!-- Botão "SOLICITE AGORA" — 317x60, border-radius 3px, bg #00d8d8 -->
      <button class="w-[317px] h-[60px] rounded-[3px] bg-[#00d8d8] mx-auto block cursor-pointer">
        <span class="font-red-hat text-[18px] font-semibold text-white uppercase">SOLICITE AGORA</span>
      </button>

      <!-- Disclaimer — 16px, regular, branco -->
      <p class="text-[16px] font-normal text-white mt-[24px] mx-auto max-w-[372px]">
        * As taxas e valores acima são apenas<br/>
        ilustrativos. As taxas reais serão calculadas de<br/>
        acordo com seu perfil de crédito quando você<br/>
        solicitar uma proposta personalizada.
      </p>
    </section>

    <!-- ═══════════════════════════════════════════ -->
    <!-- COMO FUNCIONA — fundo branco               -->
    <!-- ═══════════════════════════════════════════ -->
    <section class="bg-white py-[47px] px-[20px]">
      <!-- "Como funciona?" — 26px, bold, #00d8d8 -->
      <h2 class="text-[26px] font-bold text-[#00d8d8] mb-[40px]">
        Como funciona?
      </h2>

      <!-- Passos -->
      <div class="max-w-[300px] mx-auto space-y-[20px] mb-[40px]">
        <!-- Passo 1 -->
        <div class="flex items-start gap-[16px]">
          <div class="w-[33px] h-[34px] rounded-full bg-[#00d8d8] flex items-center justify-center flex-shrink-0">
            <span class="text-[24px] text-white leading-none">1</span>
          </div>
          <div class="text-left">
            <h3 class="text-[19px] font-bold text-[#00d8d8]">Preencha a proposta</h3>
            <p class="text-[16px] font-light text-[#5c5c5c] tracking-[0.03em] mt-[4px] leading-snug">
              Contrate seu empréstimo 100%<br/>online. Fácil, rápido e seguro.
            </p>
          </div>
        </div>

        <!-- Passo 2 -->
        <div class="flex items-start gap-[16px]">
          <div class="w-[33px] h-[34px] rounded-full bg-[#00d8d8] flex items-center justify-center flex-shrink-0">
            <span class="text-[24px] text-white leading-none">2</span>
          </div>
          <div class="text-left">
            <h3 class="text-[19px] font-bold text-[#00d8d8]">Aguarde a aprovação</h3>
            <p class="text-[16px] font-light text-[#5c5c5c] tracking-[0.04em] mt-[4px] leading-snug">
              Após a análise rápida feita<br/>pelos consultores.
            </p>
          </div>
        </div>

        <!-- Passo 3 -->
        <div class="flex items-start gap-[16px]">
          <div class="w-[33px] h-[34px] rounded-full bg-[#00d8d8] flex items-center justify-center flex-shrink-0">
            <span class="text-[24px] text-white leading-none">3</span>
          </div>
          <div class="text-left">
            <h3 class="text-[19px] font-bold text-[#00d8d8]">Receba o seu dinheiro!</h3>
            <p class="text-[16px] font-light text-[#5c5c5c] tracking-[0.04em] mt-[4px] leading-snug">
              Leia os termos, assine o contrato<br/>e receba o seu dinheiro.
            </p>
          </div>
        </div>
      </div>

      <!-- Botão "CONTRATE" — 317x60, border-radius 3px, bg #00d8d8 -->
      <button class="w-[317px] h-[60px] rounded-[3px] bg-[#00d8d8] mx-auto block cursor-pointer">
        <span class="font-red-hat text-[18px] font-semibold text-white uppercase">CONTRATE</span>
      </button>
    </section>

    <!-- ═══════════════════════════════════════════ -->
    <!-- BENEFÍCIOS — fundo #e6e6e6                 -->
    <!-- ═══════════════════════════════════════════ -->
    <section class="bg-[#e6e6e6] py-[49px] px-[20px]">
      <!-- "Atendendo suas necessidades" — 26px, bold, #00d8d8, 2 linhas -->
      <h2 class="text-[26px] font-bold text-[#00d8d8] mb-[26px]">
        Atendendo suas<br/>necessidades
      </h2>

      <!-- Grid 2x2 de cards 147x234px -->
      <div class="grid grid-cols-2 gap-[10px] mx-auto w-[307px]">
        <!-- Card 1: Fácil e rápido -->
        <div class="w-[147px] h-[234px] bg-white flex flex-col items-center justify-center text-center px-[8px]">
          <!-- Ícone placeholder (monitor/check) -->
          <div class="w-[78px] h-[70px] mb-[20px] flex items-center justify-center">
            <svg width="78" height="70" viewBox="0 0 78 70" fill="none">
              <rect x="5" y="2" width="68" height="48" rx="3" stroke="#00d8d8" stroke-width="2"/>
              <line x1="25" y1="50" x2="53" y2="50" stroke="#00d8d8" stroke-width="2"/>
              <line x1="39" y1="50" x2="39" y2="60" stroke="#00d8d8" stroke-width="2"/>
              <line x1="28" y1="60" x2="50" y2="60" stroke="#00d8d8" stroke-width="2"/>
              <path d="M25 25L33 33L53 17" stroke="#00d8d8" stroke-width="3" fill="none"/>
            </svg>
          </div>
          <h3 class="text-[17px] font-bold text-[#00d8d8] leading-tight">Fácil e<br/>rápido</h3>
          <p class="text-[14px] font-light text-[#242424] mt-[4px] leading-tight">Online e<br/>confortável<br/>para você!</p>
        </div>

        <!-- Card 2: Tempo para pagar -->
        <div class="w-[147px] h-[234px] bg-white flex flex-col items-center justify-center text-center px-[8px]">
          <div class="w-[61px] h-[70px] mb-[20px] flex items-center justify-center">
            <svg width="61" height="70" viewBox="0 0 61 70" fill="none">
              <rect x="3" y="8" width="55" height="55" rx="3" stroke="#00d8d8" stroke-width="2"/>
              <line x1="3" y1="22" x2="58" y2="22" stroke="#00d8d8" stroke-width="2"/>
              <line x1="18" y1="2" x2="18" y2="12" stroke="#00d8d8" stroke-width="2"/>
              <line x1="43" y1="2" x2="43" y2="12" stroke="#00d8d8" stroke-width="2"/>
              <rect x="10" y="30" width="12" height="10" rx="1" fill="#00d8d8"/>
            </svg>
          </div>
          <h3 class="text-[17px] font-bold text-[#00d8d8] leading-tight">Tempo para<br/>pagar</h3>
          <p class="text-[14px] font-light text-[#242424] mt-[4px] leading-tight">Parcele em<br/>até 36 vezes.</p>
        </div>

        <!-- Card 3: Menor taxa do mercado -->
        <div class="w-[147px] h-[234px] bg-white flex flex-col items-center justify-center text-center px-[8px]">
          <div class="w-[70px] h-[67px] mb-[20px] flex items-center justify-center">
            <svg width="70" height="67" viewBox="0 0 70 67" fill="none">
              <circle cx="22" cy="38" r="18" stroke="#00d8d8" stroke-width="2" fill="none"/>
              <circle cx="48" cy="38" r="18" stroke="#00d8d8" stroke-width="2" fill="none"/>
              <line x1="22" y1="30" x2="22" y2="46" stroke="#00d8d8" stroke-width="2"/>
              <line x1="14" y1="38" x2="30" y2="38" stroke="#00d8d8" stroke-width="2"/>
            </svg>
          </div>
          <h3 class="text-[17px] font-bold text-[#00d8d8] leading-tight">Menor taxa<br/>do mercado</h3>
          <p class="text-[14px] font-light text-[#242424] mt-[4px] leading-tight">Taxas a partir<br/>de 1.99% a.m.</p>
        </div>

        <!-- Card 4: R$ -->
        <div class="w-[147px] h-[234px] bg-white flex flex-col items-center justify-center text-center px-[8px]">
          <div class="w-[60px] h-[70px] mb-[20px] flex items-center justify-center">
            <svg width="60" height="70" viewBox="0 0 60 70" fill="none">
              <rect x="3" y="14" width="54" height="42" rx="3" stroke="#00d8d8" stroke-width="2"/>
              <circle cx="30" cy="35" r="10" stroke="#00d8d8" stroke-width="2" fill="none"/>
              <line x1="10" y1="14" x2="10" y2="56" stroke="#00d8d8" stroke-width="1.5"/>
              <line x1="50" y1="14" x2="50" y2="56" stroke="#00d8d8" stroke-width="1.5"/>
            </svg>
          </div>
          <h3 class="text-[17px] font-bold text-[#00d8d8] leading-tight">R$</h3>
          <p class="text-[14px] font-light text-[#242424] mt-[4px] leading-tight">Parcela que<br/>cabe no seu<br/>bolso.</p>
        </div>
      </div>
    </section>

    <!-- ═══════════════════════════════════════════ -->
    <!-- FOOTER                                      -->
    <!-- ═══════════════════════════════════════════ -->
    <footer>
      <!-- Barra preta — 84px -->
      <div class="bg-[#000000] w-full h-[84px] flex flex-col items-center justify-center px-[20px]">
        <p class="text-[12px] font-normal text-white font-roboto">Plataforma operada por Dock</p>
        <p class="text-[12px] font-normal text-white font-roboto mt-[8px]">política de privacidade e cookies</p>
      </div>

      <!-- Corpo do footer -->
      <div class="bg-white px-[61px] pt-[28px] pb-[20px] text-center">
        <p class="text-[12px] text-[#777777] font-red-hat">
          <b>Dock - Instituição de pagamentos regulada pelo Bacen</b>
        </p>
        <p class="text-[12px] text-[#777777] font-red-hat mt-[12px] leading-relaxed">
          A Dock fornece tecnologia para pagamentos e banking na América Latina. Pioneira e precursora, é o motor por
          trás da aceleração dos serviços financeiros digitais na região, reunindo soluções de emissão de cartões, conta
          digital, adquirência e prevenção a fraude, acelerando a capacidade das empresas de oferecer serviços
          inovadores aos seus clientes. Conheça mais sobre a Dock, nossas certificações e compromisso
          fundamentados nos pilares de ESG para transformarmos o futuro.
        </p>
        <p class="text-[12px] text-[#777777] font-red-hat mt-[20px] leading-relaxed">
          © Copyright 2026 - DOCK INSTITUICAO DE PAGAMENTO S.A. - CNPJ 13.370.835/0001-85<br/>
          Av. Tambore, 267, Alphaville, Barueri - SP<br/>
          06460-000.
        </p>
      </div>
    </footer>
  </div>
</template>
