<script setup lang="ts">
</script>

<template>
  <section class="bg-[#e6e6e6] py-[49px] px-[20px] text-center">
    <!-- Título — 26px, bold, #00d8d8 -->
    <h2 class="text-[26px] font-bold text-[#00d8d8] mb-[26px]">
      Atendendo suas<br/>necessidades
    </h2>

    <!-- Grid 2x2 de cards — 147x234 cada -->
    <div class="grid grid-cols-2 gap-[10px] mx-auto w-[307px]">
      <!-- Card 1: Fácil e rápido -->
      <div class="w-[147px] h-[234px] bg-white flex flex-col items-center justify-center text-center px-[8px]">
        <div class="w-[78px] h-[70px] mb-[20px] flex items-center justify-center">
          <svg width="78" height="70" viewBox="0 0 78 70" fill="none">
            <rect x="5" y="2" width="68" height="48" rx="3" stroke="#00d8d8" stroke-width="2"/>
            <line x1="25" y1="50" x2="53" y2="50" stroke="#00d8d8" stroke-width="2"/>
            <line x1="39" y1="50" x2="39" y2="60" stroke="#00d8d8" stroke-width="2"/>
            <line x1="28" y1="60" x2="50" y2="60" stroke="#00d8d8" stroke-width="2"/>
            <path d="M25 25L33 33L53 17" stroke="#00d8d8" stroke-width="3" fill="none"/>
          </svg>
        </div>
        <h3 class="text-[17px] font-bold text-[#00d8d8] leading-tight">Fácil e<br/>rápido</h3>
        <p class="text-[14px] font-light text-[#242424] mt-[4px] leading-tight">Online e<br/>confortável<br/>para você!</p>
      </div>

      <!-- Card 2: Tempo para pagar -->
      <div class="w-[147px] h-[234px] bg-white flex flex-col items-center justify-center text-center px-[8px]">
        <div class="w-[61px] h-[70px] mb-[20px] flex items-center justify-center">
          <svg width="61" height="70" viewBox="0 0 61 70" fill="none">
            <rect x="3" y="8" width="55" height="55" rx="3" stroke="#00d8d8" stroke-width="2"/>
            <line x1="3" y1="22" x2="58" y2="22" stroke="#00d8d8" stroke-width="2"/>
            <line x1="18" y1="2" x2="18" y2="12" stroke="#00d8d8" stroke-width="2"/>
            <line x1="43" y1="2" x2="43" y2="12" stroke="#00d8d8" stroke-width="2"/>
            <rect x="10" y="30" width="12" height="10" rx="1" fill="#00d8d8"/>
          </svg>
        </div>
        <h3 class="text-[17px] font-bold text-[#00d8d8] leading-tight">Tempo para<br/>pagar</h3>
        <p class="text-[14px] font-light text-[#242424] mt-[4px] leading-tight">Parcele em<br/>até 36 vezes.</p>
      </div>

      <!-- Card 3: Menor taxa do mercado -->
      <div class="w-[147px] h-[234px] bg-white flex flex-col items-center justify-center text-center px-[8px]">
        <div class="w-[70px] h-[67px] mb-[20px] flex items-center justify-center">
          <svg width="70" height="67" viewBox="0 0 70 67" fill="none">
            <circle cx="22" cy="38" r="18" stroke="#00d8d8" stroke-width="2" fill="none"/>
            <circle cx="48" cy="38" r="18" stroke="#00d8d8" stroke-width="2" fill="none"/>
            <line x1="22" y1="30" x2="22" y2="46" stroke="#00d8d8" stroke-width="2"/>
            <line x1="14" y1="38" x2="30" y2="38" stroke="#00d8d8" stroke-width="2"/>
          </svg>
        </div>
        <h3 class="text-[17px] font-bold text-[#00d8d8] leading-tight">Menor taxa<br/>do mercado</h3>
        <p class="text-[14px] font-light text-[#242424] mt-[4px] leading-tight">Taxas a partir<br/>de 1.99% a.m.</p>
      </div>

      <!-- Card 4: R$ -->
      <div class="w-[147px] h-[234px] bg-white flex flex-col items-center justify-center text-center px-[8px]">
        <div class="w-[60px] h-[70px] mb-[20px] flex items-center justify-center">
          <svg width="60" height="70" viewBox="0 0 60 70" fill="none">
            <rect x="3" y="14" width="54" height="42" rx="3" stroke="#00d8d8" stroke-width="2"/>
            <circle cx="30" cy="35" r="10" stroke="#00d8d8" stroke-width="2" fill="none"/>
            <line x1="10" y1="14" x2="10" y2="56" stroke="#00d8d8" stroke-width="1.5"/>
            <line x1="50" y1="14" x2="50" y2="56" stroke="#00d8d8" stroke-width="1.5"/>
          </svg>
        </div>
        <h3 class="text-[17px] font-bold text-[#00d8d8] leading-tight">R$</h3>
        <p class="text-[14px] font-light text-[#242424] mt-[4px] leading-tight">Parcela que<br/>cabe no seu<br/>bolso.</p>
      </div>
    </div>
  </section>
</template>
