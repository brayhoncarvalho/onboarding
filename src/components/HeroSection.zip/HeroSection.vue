<script setup lang="ts">
</script>

<template>
  <section class="relative z-10 bg-white">
    <header class="flex items-center justify-between px-5 h-[63px] bg-white">
      <img src="/dock.png" alt="Dock" class="h-8 w-auto" />
      <button class="flex h-10 w-10 flex-col items-center justify-center gap-[3px] rounded-lg bg-[#ececec]" aria-label="Menu">
        <span class="block h-[2px] w-4 rounded-full bg-[#9a9a9a]"></span>
        <span class="block h-[2px] w-4 rounded-full bg-[#9a9a9a]"></span>
        <span class="block h-[2px] w-4 rounded-full bg-[#9a9a9a]"></span>
      </button>
    </header>

    <section class="relative">
      <div class="relative z-10 mx-[11px] mt-[20px]">
        <div class="inline-flex flex-col items-start justify-start rounded-[34px] bg-[#1cc0c0] w-[259px] h-[154px] px-[25px] pt-[22px] text-left">
          <p class="text-[18px] font-medium text-white uppercase leading-tight w-[170px]">
            Feito de pessoas,<br/>para pessoas.
          </p>
          <p class="text-[22px] font-bold text-white uppercase leading-[24px] tracking-[-0.06em] mt-[16px] w-[224px]">
            Empréstimo Online,<br/>Rápido e Seguro.
          </p>
        </div>
      </div>

      <div class="relative mx-auto flex w-full justify-center">
        <img
          src="/image-header.png"
          alt="Pessoa usando tablet"
          class="-mt-[210px] w-full max-w-[416px] object-contain relative z-0"
        />
      </div>
    </section>
  </section>
</template>
