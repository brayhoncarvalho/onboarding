<script setup lang="ts">
import { ref, computed } from 'vue'

const emit = defineEmits<{
  (e: 'next'): void
}>()

const valorEmprestimo = ref(69000)
const parcelasSelecionada = ref(18)
const opcoesParcelas = [6, 12, 16, 18, 24, 36]

const valorFormatado = computed(() =>
  valorEmprestimo.value.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
  })
)

const parcelaMin = computed(() => {
  const v = valorEmprestimo.value / parcelasSelecionada.value
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })
})

const parcelaMax = computed(() => {
  const v = (valorEmprestimo.value / parcelasSelecionada.value) * 1.75
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2 })
})

function incrementar() {
  valorEmprestimo.value = Math.min(200000, valorEmprestimo.value + 1000)
}

function decrementar() {
  valorEmprestimo.value = Math.max(1000, valorEmprestimo.value - 1000)
}
</script>

<template>
  <section class="bg-[#1cc0c0] px-[20px] pt-[40px] pb-[40px] text-center">
    <!-- "De quanto você precisa?" — 26px, bold, branco -->
    <h2 class="text-[26px] font-bold text-white mb-[20px]">
      De quanto você precisa?
    </h2>

    <!-- Campo valor — 229x81, bg #eeff88, border 1px #fff -->
    <div class="mx-auto w-[229px] h-[81px] bg-[#eeff88] border border-white flex items-center justify-center mb-[20px]">
      <span class="text-[30px] font-medium text-[#00d8d8]">{{ valorFormatado }}</span>
    </div>

    <!-- Slider com +/- e <input type="range"> FUNCIONAL -->
    <div class="flex items-center gap-[10px] mx-auto max-w-[375px] mb-[30px] px-[19px]">
      <!-- Botão - (decrementar) — à ESQUERDA (lado do min) -->
      <button
        class="w-[29px] h-[29px] bg-[#00d8d8] flex items-center justify-center text-[24px] font-medium text-white flex-shrink-0 cursor-pointer"
        @click="decrementar"
      >-</button>

      <!-- Input range nativo estilizado -->
      <div class="flex-1 relative">
        <input
          type="range"
          :min="1000"
          :max="200000"
          :step="1000"
          v-model.number="valorEmprestimo"
          class="slider-range w-full cursor-pointer"
        />
      </div>

      <!-- Botão + (incrementar) — à DIREITA (lado do max) -->
      <button
        class="w-[29px] h-[29px] bg-[#00d8d8] flex items-center justify-center text-[24px] font-medium text-white flex-shrink-0 cursor-pointer"
        @click="incrementar"
      >+</button>
    </div>

    <!-- "Em quantas vezes?" — 26px, bold -->
    <h3 class="text-[26px] font-bold text-white mb-[24px]">
      Em quantas vezes?
    </h3>

    <!-- Grid parcelas 3x2 — 83x65 cada -->
    <div class="grid grid-cols-3 gap-0 mx-auto w-[249px] mb-[24px]">
      <button
        v-for="parcela in opcoesParcelas"
        :key="parcela"
        class="w-[83px] h-[65px] border border-white flex items-center justify-center text-[30px] font-medium cursor-pointer"
        :class="parcela === parcelasSelecionada
          ? 'bg-[#eeff88] text-[#00d8d8]'
          : 'bg-[#00d8d8] text-white'"
        @click="parcelasSelecionada = parcela"
      >
        {{ parcela }}
      </button>
    </div>

    <!-- Parcelas mensal — 26px -->
    <div class="mb-[16px]">
      <span class="text-[26px] font-light text-white">Parcelas mensal*</span>
      <br/>
      <span class="text-[26px] font-medium text-white">{{ parcelaMin }} a {{ parcelaMax }}</span>
    </div>

    <!-- Taxa de juros — 24px -->
    <div class="mb-[24px]">
      <span class="text-[24px] font-light text-white">Taxa de Juros*</span>
      <br/>
      <span class="text-[24px] font-medium text-white">1,99% a 4,99%</span>
    </div>

    <!-- Botão "SOLICITE AGORA" — 317x60, border-radius 3px -->
    <button
      class="w-[317px] h-[60px] rounded-[3px] bg-[#00d8d8] mx-auto block cursor-pointer"
      @click="emit('next')"
    >
      <span class="font-red-hat text-[18px] font-semibold text-white uppercase">SOLICITE AGORA</span>
    </button>

    <!-- Disclaimer — 16px -->
    <p class="text-[16px] font-normal text-white mt-[24px] mx-auto max-w-[372px]">
      * As taxas e valores acima são apenas
      ilustrativos. As taxas reais serão calculadas de
      acordo com seu perfil de crédito quando você
      solicitar uma proposta personalizada.
    </p>
  </section>
</template>

<style scoped>
.slider-range {
  -webkit-appearance: none;
  appearance: none;
  height: 10px;
  background: #b9b9b9;
  outline: none;
  border-radius: 0;
}

.slider-range::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 24px;
  height: 24px;
  background: #ffffff;
  cursor: pointer;
  border: none;
  border-radius: 0;
  box-shadow: none;
  margin-top: -7px;
}

.slider-range::-moz-range-thumb {
  width: 24px;
  height: 24px;
  background: #ffffff;
  cursor: pointer;
  border: none;
  border-radius: 0;
  box-shadow: none;
}

.slider-range::-webkit-slider-runnable-track {
  height: 10px;
  background: #b9b9b9;
  border-radius: 0;
}

.slider-range::-moz-range-track {
  height: 10px;
  background: #b9b9b9;
  border-radius: 0;
}
</style>
