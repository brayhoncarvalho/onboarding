<script setup lang="ts">
const emit = defineEmits<{
  (e: 'next'): void
}>()
</script>

<template>
  <section class="bg-white py-[47px] px-[20px] text-center">
    <!-- Título — 26px, bold, #00d8d8 -->
    <h2 class="text-[26px] font-bold text-[#00d8d8] mb-[40px]">
      Como funciona?
    </h2>

    <div class="max-w-[300px] mx-auto space-y-[20px] mb-[40px]">
      <!-- Passo 1 -->
      <div class="flex items-start gap-[16px]">
        <div class="w-[33px] h-[34px] rounded-full bg-[#00d8d8] flex items-center justify-center flex-shrink-0">
          <span class="text-[24px] text-white leading-none">1</span>
        </div>
        <div class="text-left">
          <h3 class="text-[19px] font-bold text-[#00d8d8]">Preencha a proposta</h3>
          <p class="text-[16px] font-light text-[#5c5c5c] tracking-[0.03em] mt-[4px] leading-snug">
            Contrate seu empréstimo 100%<br/>online. Fácil, rápido e seguro.
          </p>
        </div>
      </div>

      <!-- Passo 2 -->
      <div class="flex items-start gap-[16px]">
        <div class="w-[33px] h-[34px] rounded-full bg-[#00d8d8] flex items-center justify-center flex-shrink-0">
          <span class="text-[24px] text-white leading-none">2</span>
        </div>
        <div class="text-left">
          <h3 class="text-[19px] font-bold text-[#00d8d8]">Aguarde a aprovação</h3>
          <p class="text-[16px] font-light text-[#5c5c5c] tracking-[0.04em] mt-[4px] leading-snug">
            Após a análise rápida feita<br/>pelos consultores.
          </p>
        </div>
      </div>

      <!-- Passo 3 -->
      <div class="flex items-start gap-[16px]">
        <div class="w-[33px] h-[34px] rounded-full bg-[#00d8d8] flex items-center justify-center flex-shrink-0">
          <span class="text-[24px] text-white leading-none">3</span>
        </div>
        <div class="text-left">
          <h3 class="text-[19px] font-bold text-[#00d8d8]">Receba o seu dinheiro!</h3>
          <p class="text-[16px] font-light text-[#5c5c5c] tracking-[0.04em] mt-[4px] leading-snug">
            Leia os termos, assine o contrato<br/>e receba o seu dinheiro.
          </p>
        </div>
      </div>
    </div>

    <!-- Botão "CONTRATE" — 317x60, border-radius 3px -->
    <button
      class="w-[317px] h-[60px] rounded-[3px] bg-[#00d8d8] mx-auto block cursor-pointer"
      @click="emit('next')"
    >
      <span class="font-red-hat text-[18px] font-semibold text-white uppercase">CONTRATE</span>
    </button>
  </section>
</template>
