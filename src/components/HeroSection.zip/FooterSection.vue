<script setup lang="ts">
</script>

<template>
  <footer>
    <!-- Barra superior — fundo #000, 84px -->
    <div class="bg-[#000000] w-full h-[84px] flex flex-col items-center justify-center px-[20px]">
      <p class="text-[12px] font-normal text-white font-roboto">Plataforma operada por Dock</p>
      <p class="text-[12px] font-normal text-white font-roboto mt-[8px]">política de privacidade e cookies</p>
    </div>

    <!-- Corpo — fundo branco -->
    <div class="bg-white px-[61px] pt-[28px] pb-[20px] text-center">
      <p class="text-[12px] text-[#777777] font-red-hat">
        <b>Dock - Instituição de pagamentos regulada pelo Bacen</b>
      </p>
      <p class="text-[12px] text-[#777777] font-red-hat mt-[12px] leading-relaxed">
        A Dock fornece tecnologia para pagamentos e banking na América Latina. Pioneira e precursora, é o motor por
        trás da aceleração dos serviços financeiros digitais na região, reunindo soluções de emissão de cartões, conta
        digital, adquirência e prevenção a fraude, acelerando a capacidade das empresas de oferecer serviços
        inovadores aos seus clientes. Conheça mais sobre a Dock, nossas certificações e compromisso
        fundamentados nos pilares de ESG para transformarmos o futuro.
      </p>
      <p class="text-[12px] text-[#777777] font-red-hat mt-[20px] leading-relaxed">
        © Copyright 2026 - DOCK INSTITUICAO DE PAGAMENTO S.A. - CNPJ 13.370.835/0001-85<br/>
        Av. Tambore, 267, Alphaville, Barueri - SP<br/>
        06460-000.
      </p>
    </div>
  </footer>
</template>
