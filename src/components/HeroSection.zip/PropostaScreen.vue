<script setup lang="ts">
import { reactive } from 'vue'

const form = reactive({
  nome: 'Franciele Santos de Jesus',
  cpf: '412.456.508-90',
  nascimento: '2000-05-29',
  valorEmprestimo: 'R$ 69.000,00',
  motivo: 'Pagamento de dívidas',
  renda: 'R$ 6.000,00',
  autorizacaoDados: true,
  autorizacaoPagamento: true,
})

const motivosEmprestimo = [
  'Pagamento de dívidas',
  'Capital de giro',
  'Reforma',
  'Investimento pessoal',
]
</script>

<template>
  <section class="min-h-screen bg-white">
    <header class="flex items-center justify-between bg-[#efefef] px-4 py-2.5">
      <img src="/dock.png" alt="Dock" class="h-8 w-auto" />

      <button class="flex h-10 w-10 flex-col items-center justify-center gap-[3px] rounded-lg bg-[#e0e0e0]" aria-label="Menu">
        <span class="block h-[2px] w-4 rounded-full bg-[#a8a8a8]"></span>
        <span class="block h-[2px] w-4 rounded-full bg-[#a8a8a8]"></span>
        <span class="block h-[2px] w-4 rounded-full bg-[#a8a8a8]"></span>
      </button>
    </header>

    <div class="mx-auto max-w-[360px] px-9 pb-10 pt-6">
      <h1 class="text-center text-[2.05rem] font-semibold leading-[1.05] text-dock-cyan">
        Solicite uma proposta
        <br />
        sem compromisso
      </h1>

      <form class="mt-8 space-y-3.5">
        <label class="block">
          <span class="mb-1.5 block text-[13px] text-dock-gray-700">Nome completo*</span>
          <input
            v-model="form.nome"
            type="text"
            class="h-10 w-full border border-[#b8b8b8] bg-white px-2.5 text-[13px] text-dock-gray-700 outline-none transition-colors focus:border-dock-cyan"
          />
        </label>

        <label class="block">
          <span class="mb-1.5 block text-[13px] text-dock-gray-700">CPF*</span>
          <input
            v-model="form.cpf"
            type="text"
            class="h-10 w-full border border-[#b8b8b8] bg-white px-2.5 text-[13px] text-dock-gray-700 outline-none transition-colors focus:border-dock-cyan"
          />
        </label>

        <label class="block">
          <span class="mb-1.5 block text-[13px] text-dock-gray-700">Data de Nascimento*</span>
          <input
            v-model="form.nascimento"
            type="date"
            class="h-10 w-full border border-[#b8b8b8] bg-white px-2.5 text-[13px] text-dock-gray-700 outline-none transition-colors focus:border-dock-cyan"
          />
        </label>

        <label class="block">
          <span class="mb-1.5 block text-[13px] text-dock-gray-700">Valor do Empréstimo*</span>
          <input
            v-model="form.valorEmprestimo"
            type="text"
            class="h-10 w-full border border-[#b8b8b8] bg-white px-2.5 text-[13px] text-dock-gray-700 outline-none transition-colors focus:border-dock-cyan"
          />
        </label>

        <label class="block">
          <span class="mb-1.5 block text-[13px] text-dock-gray-700">Motivo do Empréstimo*</span>
          <select
            v-model="form.motivo"
            class="h-10 w-full border border-[#b8b8b8] bg-white px-2.5 text-[13px] text-dock-gray-700 outline-none transition-colors focus:border-dock-cyan"
          >
            <option v-for="motivo in motivosEmprestimo" :key="motivo" :value="motivo">
              {{ motivo }}
            </option>
          </select>
        </label>

        <label class="block">
          <span class="mb-1.5 block text-[13px] text-dock-gray-700">Renda bruta mensal*</span>
          <input
            v-model="form.renda"
            type="text"
            class="h-10 w-full border border-[#b8b8b8] bg-white px-2.5 text-[13px] text-dock-gray-700 outline-none transition-colors focus:border-dock-cyan"
          />
        </label>

        <p class="pt-0.5 text-[11px] text-dock-gray-700">* preenchimento obrigatório</p>

        <label class="flex items-start gap-2 pt-1 text-[10px] leading-[1.35] text-dock-gray-600">
          <input v-model="form.autorizacaoDados" type="checkbox" class="mt-0.5 h-3.5 w-3.5 flex-shrink-0 accent-dock-cyan" />
          <span>
            Autorizo o compartilhamento dos meus dados cadastrais com o Banco Semear, bem como a consulta prévia de minhas informações cadastrais nos órgãos de proteção ao crédito (BoaVista, Serasa, SPC Brasil, por exemplo) e no Sistema de informações de Crédito do Banco Central do Brasil (SCR), com o objetivo de possibilitar uma análise de crédito adequada.
          </span>
        </label>

        <label class="flex items-start gap-2 pt-1 text-[10px] leading-[1.35] text-dock-gray-600">
          <input v-model="form.autorizacaoPagamento" type="checkbox" class="mt-0.5 h-3.5 w-3.5 flex-shrink-0 accent-dock-cyan" />
          <span>
            Autorizo o débito mensal referente na folha de pagamento, das parcelas do empréstimo contratado junto à CrediFera. Os valores e datas de vencimento dependerão dos termos contratados e serão confirmados junto ao cliente antes da conclusão do empréstimo.
          </span>
        </label>

        <button
          type="button"
          class="mt-4 h-12 w-full bg-dock-cyan text-base font-medium uppercase tracking-wide text-white transition-colors hover:bg-dock-cyan-dark"
        >
          CONTINUAR
        </button>
      </form>
    </div>
  </section>
</template>